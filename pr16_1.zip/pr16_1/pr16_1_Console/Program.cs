﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace pr16_1_Console
{
    internal class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Console.Write("Введите слово для поиска: ");
                string word = Console.ReadLine().ToLower();
                Console.Write("Введите название файла с расширением: ");
                string fn = Console.ReadLine();
                string text = File.ReadAllText(fn);
                Console.WriteLine($"-----------------------\nТекст: {text}");
                int count = Regex.Matches(text.ToLower(), word).Count;
                if (count > 0)
                    Console.WriteLine($"Были найдены {count} вхождений запроса \"{word}\"");
                else
                    Console.WriteLine($"Не было найдено вхождений запроса \"{word}\"");
            } catch { Console.WriteLine("Не правильный ввод названия файла"); }
        }
    }
}
