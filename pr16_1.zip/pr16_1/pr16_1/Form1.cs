﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pr16_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "")
            {
                string[] stroki = textBox1.Text.Split(new[] { Environment.NewLine }, StringSplitOptions.None);
                int a = stroki.Sum(str => str.Count(ch => char.IsDigit(ch)));
                textBox2.Text = a.ToString();
                var b = stroki.TakeWhile(str => !str.Contains("/")).ToArray();
                textBox3.Text = string.Join(Environment.NewLine, b);
                var c = stroki.SkipWhile(str => !str.Contains("/")).Skip(1).Select(str => new string(str.Select(ch => char.IsLetter(ch) ? char.ToUpper(ch) : ch).ToArray())).ToArray();
                textBox4.Text = string.Join(Environment.NewLine, c);
                File.WriteAllLines("file1.txt", c);
            }
            else
                MessageBox.Show("Для начала введите строки", "Так нельзя", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
