﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pr16_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (textBox1.Text != "" && textBox1.Text != " ")
                {
                    textBox2.Clear();
                    textBox3.Clear();
                    float[] a = textBox1.Text.Split(new[] { ' ', ';' }, StringSplitOptions.RemoveEmptyEntries).Select(float.Parse).ToArray();
                    Dictionary<float, int> ch = new Dictionary<float, int>();
                    foreach (float number in a)
                    {
                        if (ch.ContainsKey(number))
                            ch[number]++;
                        else
                            ch[number] = 1;
                    }
                    foreach (var pair in ch)
                    {
                        textBox2.Text += ($"\n{pair.Key}\t{pair.Value}{Environment.NewLine}");
                        textBox3.Text += $"\n{pair.Key * pair.Value}\t{pair.Value}{Environment.NewLine}";
                    }
                }
                else
                    MessageBox.Show("Для начала введите массив чисел", "Поле пустое", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch { MessageBox.Show("Не правильный ввод, введен символ", "Не то", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        }
    }
}
